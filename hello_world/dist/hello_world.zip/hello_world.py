import os

def hello_world():
	print("-------> CLAYTHON SAYS ------ HELLO")
	pass


if __name__ == "__main__":
	hello_world()
